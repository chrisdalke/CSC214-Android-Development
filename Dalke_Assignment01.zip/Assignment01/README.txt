=============================
CSC 214 - Assignment 01
Chris Dalke
TA: Mariana Kim
=============================


====== Lab Description ======

For this assignment we were tasked with setting up a basic hello world project.
I completed the assignment by setting up the basic Android Studio project. My project is in the HelloChris directory and screenshots of my resulting program are in the SampleOutput directory, as the assignment specified.

=============================
Contact Info: 
Email: cdalke@u.rochester.edu
=============================
